#!/usr/bin/env bash
# Deploy phone app to GitHub Pages — NO Mac needed.
# Mom: open the link in Safari → Share → Add to Home Screen
set -euo pipefail
cd "$(dirname "$0")"

REPO="${ASSISTANT_LAB_PAGES_REPO:-OwendoyalAdastra-lang/assistant-lab-mobile-pages}"
PAGES_URL="https://owendoyaladastra-lang.github.io/assistant-lab-mobile-pages/"

./build-mobile.sh

WORKDIR=$(mktemp -d)
trap 'rm -rf "$WORKDIR"' EXIT

git clone "https://github.com/${REPO}.git" "$WORKDIR/repo" 2>/dev/null || {
  echo ""
  echo "First time? Create an empty repo on GitHub:"
  echo "  https://github.com/new  → name: assistant-lab-mobile-pages"
  echo "  (empty, no README)"
  echo ""
  echo "Then run this script again."
  exit 1
}

rm -rf "$WORKDIR/repo"/*
cp -a build/web/* "$WORKDIR/repo/"
touch "$WORKDIR/repo/.nojekyll"

cat > "$WORKDIR/repo/README.md" << EOF
# Assistant Lab — Phone

Open on iPhone: ${PAGES_URL}

Safari → Share → **Add to Home Screen**
EOF

cd "$WORKDIR/repo"
git add -A
git commit -m "Deploy mobile web app $(date +%Y-%m-%d)" || true
git branch -M gh-pages
git push -f origin gh-pages

echo ""
echo "Live at: ${PAGES_URL}"
echo ""
echo "Tell mom:"
echo "  1. Open that link in Safari"
echo "  2. Share → Add to Home Screen"
echo "  3. Tap the Assistant Lab icon — it's her app!"