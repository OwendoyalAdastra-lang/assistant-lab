# /// script
# dependencies = []
# ///
"""
Assistant Lab — phone/tablet app (browser + home screen).

Built with pygbag. Single-player build + shop works on phone.
Multiplayer chat is desktop-only.
"""
import asyncio

import assistant_lab_mobile_boot

assistant_lab_mobile_boot.apply()

from build_your_own_smart_assistant_pygame import main

asyncio.run(main())