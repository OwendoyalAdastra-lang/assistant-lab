# Assistant Lab — Phone App

Runs in the browser on **iPhone and Android**. Mom can tap **Add to Home Screen** so it looks like an app.

## What works on phone

- Build your assistant (all 7 questions)
- Shop, crates, cosmetics, saves
- Touch = click, on-screen keyboard for typing

## What needs a computer

- Multiplayer chat, trade, Social Lab

## Build

```bash
chmod +x build-mobile.sh
./build-mobile.sh
```

Test on your network:
```bash
cd build/web && python3 -m http.server 8080
```
On mom's phone (same Wi-Fi): `http://YOUR_COMPUTER_IP:8080`

## Give mom a permanent link

Upload `build/web/` to:
- **GitHub Pages** (free), or
- **Netlify** drag-and-drop (free)

She opens the link in **Safari** (iPhone) → Share → **Add to Home Screen**.

## No Mac needed

You do **not** need your iMac. Mom gets an app icon via **Add to Home Screen** in Safari.

```bash
./deploy-pages.sh   # puts it on GitHub Pages (one-time repo setup)
```

Or test on same Wi-Fi: `./serve-phone.sh`

## Not an App Store IPA

A true App Store app needs a Mac + $99/year. The home-screen method is the same for mom — tap the icon, play the game.