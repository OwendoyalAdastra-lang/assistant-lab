#!/usr/bin/env bash
# Share on local Wi-Fi so mom can test on her phone
set -euo pipefail
cd "$(dirname "$0")/build/web"
IP=$(hostname -I 2>/dev/null | awk '{print $1}' || echo "127.0.0.1")
echo "On mom's phone (same Wi-Fi), open:"
echo "  http://${IP}:8080"
echo ""
exec python3 -m http.server 8080 --bind 0.0.0.0