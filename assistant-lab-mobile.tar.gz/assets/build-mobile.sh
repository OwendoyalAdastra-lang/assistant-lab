#!/usr/bin/env bash
# Build Assistant Lab for phone (web app — Add to Home Screen on iPhone/Android)
set -euo pipefail
cd "$(dirname "$0")"

if ! python3 -c "import pygbag" 2>/dev/null; then
  python3 -m pip install pygbag --user --break-system-packages 2>/dev/null \
    || python3 -m pip install pygbag --user
fi

echo "Building mobile web app (this may take a few minutes first time)..."
python3 -m pygbag \
  --app_name assistant-lab-mobile \
  --title "Assistant Lab" \
  --ume_block 0 \
  --build \
  . || { echo "Build failed — check errors above."; exit 1; }

# PWA manifest so mom can Add to Home Screen
cat > build/web/manifest.json << 'EOF'
{
  "name": "Assistant Lab",
  "short_name": "Assistant Lab",
  "description": "Build Your Own Smart Assistant",
  "start_url": "./",
  "display": "standalone",
  "background_color": "#0e1220",
  "theme_color": "#64c8ff",
  "orientation": "landscape"
}
EOF

if [[ -f build/web/index.html ]] && ! grep -q manifest.json build/web/index.html; then
  sed -i 's|</head>|<link rel="manifest" href="manifest.json">\n<meta name="apple-mobile-web-app-capable" content="yes">\n<meta name="apple-mobile-web-app-title" content="Assistant Lab">\n</head>|' build/web/index.html
fi

echo ""
echo "Done! Test locally:"
echo "  cd build/web && python3 -m http.server 8080"
echo "  Open http://localhost:8080 on your phone (same Wi-Fi)"
echo ""
echo "Or upload the build/web folder to GitHub Pages / Netlify for mom's link."