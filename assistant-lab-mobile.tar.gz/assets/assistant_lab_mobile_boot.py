"""Patches for phone/web build (pygbag). Multiplayer disabled in browser."""
from __future__ import annotations

import os
import sys

IS_WEB = sys.platform == "emscripten"
IS_MOBILE = IS_WEB or os.environ.get("ASSISTANT_LAB_MOBILE") == "1"


def apply() -> None:
    if not IS_MOBILE:
        return
    os.environ.setdefault("ASSISTANT_LAB_MOBILE", "1")
    _patch_chat()
    _patch_save_path()


def _patch_save_path() -> None:
    import assistant_lab_data as data

    if IS_WEB:
        data.SAVE_PATH = "/data/assistant_lab_save.json"
    else:
        data.SAVE_PATH = os.path.join(os.path.expanduser("~"), "assistant_lab_save.json")


def _patch_chat() -> None:
    import assistant_lab_chat as chat

    class MobileChatClient:
        connected = False
        player_name = "Player"
        last_error = "Multiplayer is available on computer only."
        host = chat.DEFAULT_HOST
        port = chat.DEFAULT_PORT

        def poll_events(self):
            return []

        def connect(self, player_name: str) -> bool:
            self.last_error = "Chat works on computer — build & shop work here!"
            return False

        def disconnect(self) -> None:
            self.connected = False

        def send_message(self, text: str):
            return False, self.last_error

        def send_crate_drop(self, **kwargs) -> None:
            pass

        def send_trade_offer(self, *a, **k):
            return False, self.last_error

        def send_trade_confirm(self, *a, **k):
            return False, self.last_error

        def send_trade_cancel(self, *a, **k):
            return False, self.last_error

        def send_world_join(self, *a, **k):
            return False, self.last_error

        def send_world_move(self, *a, **k) -> None:
            pass

        def send_world_leave(self) -> None:
            pass

        def send_world_emote(self) -> None:
            pass

        def send_world_flex_update(self, *a, **k) -> None:
            pass

    chat.ChatClient = MobileChatClient  # type: ignore[misc, assignment]